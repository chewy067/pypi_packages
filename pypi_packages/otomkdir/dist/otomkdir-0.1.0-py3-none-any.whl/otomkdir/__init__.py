from otomkdir import otomkdir
