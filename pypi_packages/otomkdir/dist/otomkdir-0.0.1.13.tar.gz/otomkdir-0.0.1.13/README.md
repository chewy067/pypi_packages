
# otomkdir
otomkdir is a Python library to automate creation of folders and subfolders.

## Installation
Use the package manager "pip install" to install otomkdir.

```bash
pip install otomkdir
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## Contributor/s
mose_tucker_0159 -- mose.tucker.0159@gmail.com

## License
[MIT]( https://choosealicense.com/licenses/mit )
