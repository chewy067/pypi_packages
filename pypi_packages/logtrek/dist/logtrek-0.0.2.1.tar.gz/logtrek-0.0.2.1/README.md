
# logtrek
logtrek is a Python library to generate a log tracking mechanism that can be customised.

## Installation
Use the package manager "pip install" to install logtrek.

```bash
pip install logtrek
```

## Contributing
Pull requests are welcome.

## Contributor/s
mose_tucker_0159 -- mose.tucker.0159@gmail.com

## License
[MIT]( https://choosealicense.com/licenses/mit )
