
# inkript
inkript is a Python library to create keys to encrypt and decrypt files.

## Installation
Use the package manager "pip install" to install inkript.

```bash
pip install inkript
```

## Contributing
Pull requests are welcome.

## Contributor/s
mose_tucker_0159 -- mose.tucker.0159@gmail.com

## License
[MIT]( https://choosealicense.com/licenses/mit )
